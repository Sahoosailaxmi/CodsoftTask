module StudentGradeCalculator {
}