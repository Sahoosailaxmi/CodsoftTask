package com.sailaxmi.studentGrade;

import java.util.Scanner;

public class StudentGradingSystem {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of students: ");
        int numStudents = scanner.nextInt();
        Student[] students = new Student[numStudents];

        for (int i = 0; i < numStudents; i++) {
        	System.out.print("Enter student id: ");
            int id = scanner.nextInt();
            System.out.print("Enter student name: ");
            String name = scanner.next();
            System.out.print("Enter student score: ");
            int score = scanner.nextInt();
            students[i] = new Student(id, name, score);
        }
        scanner.close();

        for (Student student : students) {
            System.out.println(" Student Id: " +student.getId() + "\n Name: " + student.getName() + "\n Grade: " + student.getGrade());
        }

	}

}
