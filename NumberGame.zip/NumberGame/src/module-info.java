module NumberGame {
	requires java.desktop;
}